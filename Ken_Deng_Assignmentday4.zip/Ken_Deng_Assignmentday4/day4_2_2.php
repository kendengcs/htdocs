<?php
  session_start();
  echo "Welcome ".$_SESSION[firstname]." here, have a good day!";


 ?>
